package com.example.demo;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

// Handles showing the form and processing submissions
@Controller
public class GreetingController {

    @GetMapping("/greeting")
    public String greetingForm(Model model) {
        model.addAttribute("greeting", new Greeting());
        model.addAttribute("error", "");
        return "greeting";
    }

    @PostMapping("/greeting")
    public String greetingSubmit(@ModelAttribute Greeting greeting, Model model) {
        if (!greeting.getId().matches("V\\d+")) {
            model.addAttribute("error", "Student ID must start with 'V' followed by numbers.");
        } else {
            try {
                String dateInput = greeting.getYear() + "-" + greeting.getMonth() + "-" + greeting.getDay();
                LocalDate parsedDate = LocalDate.parse(dateInput);
                greeting.setFullDate(parsedDate.format(DateTimeFormatter.ofPattern("MM/dd/yyyy")));
                model.addAttribute("greeting", greeting);
                return "result";
            } catch (DateTimeParseException e) {
                model.addAttribute("error", "Invalid date. Please enter a real date.");
            }
        }

        // If validation fails, reload form with error and previous data
        model.addAttribute("greeting", greeting);
        return "greeting";
    }
}
