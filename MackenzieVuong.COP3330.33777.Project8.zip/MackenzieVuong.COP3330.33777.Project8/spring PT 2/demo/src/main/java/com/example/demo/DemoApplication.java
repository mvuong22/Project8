/*
 * Name: Mackenzie Vuong
 * Course: COP 3330C 33777
 * Date: 7/19/25
 *
 * Project 8: Greeting Form Submission
 * Objective:
 * This program lets users enter their student ID, a date, and a message via a web form.
 * It validates the date input and then displays the submitted data on a results page.
 *
 * Inputs:
 * - Student ID (text)
 * - Date (month, day, year as separate fields)
 * - Message (text)
 * Outputs:
 * - Displays the entered information back to the user in a formatted results page.
 * - Shows an error message if the date entered is invalid.
 */

package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}

}
