package com.example.demo;

public class Greeting {

    private String id;           // Student ID (using mine as the format, V03727338)
    private String content;      // Custom message

    private String month;
    private String day;
    private String year;

    private String fullDate;     // Formatted as MM/DD/YYYY

    // Getters & setters

    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }

    public String getContent() {
        return content;
    }
    public void setContent(String content) {
        this.content = content;
    }

    public String getMonth() {
        return month;
    }
    public void setMonth(String month) {
        this.month = month;
    }

    public String getDay() {
        return day;
    }
    public void setDay(String day) {
        this.day = day;
    }

    public String getYear() {
        return year;
    }
    public void setYear(String year) {
        this.year = year;
    }

    public String getFullDate() {
        return fullDate;
    }
    public void setFullDate(String fullDate) {
        this.fullDate = fullDate;
    }
}
